#!/bin/bash/

rm node* obj*
g++ ccbplus.cpp -o ccbplus
reset
./ccbplus
