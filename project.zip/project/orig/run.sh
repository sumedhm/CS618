#!/bin/bash/

rm node* obj*
g++ bplus.cpp -o bplus
reset
./bplus
