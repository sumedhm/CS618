#!/bin/bash/

g++ try.cpp -o try
#reset
./try $1
